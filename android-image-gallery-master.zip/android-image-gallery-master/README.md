### Android image gallery sample 

#### Reference
- based on [ImageViewFlipper](http://androidworkz.com/2010/07/06/source-code-imageview-flipper-sd-card-scanner/)  
- based on [Hello Android! example for zoom](http://pragprog.com/titles/eband/hello-android)  

#### Purpose  
- sample codes for who want to implement gallery feature in your android app  

#### Basic Gallery Features  
- gallery view  
- full page view  
- drag  
- zoom in/out  
- swipe to next picture  

#### contributed by  
- [@alvinsj](http://twitter.com/alvinsj)  
